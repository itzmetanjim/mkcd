# mkcd
Get all linux utilities like grep,head,tail,etc in Powershell and CMD directly
